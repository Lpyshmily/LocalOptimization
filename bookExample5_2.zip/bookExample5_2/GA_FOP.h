#ifndef GA_FOP_H_
#define GA_FOP_H_

int GA_FOP(double* Out, const double* rv0, const double* rv1, double m0, double tof, double epsi, int MaxGuessNum, const double* rv_middle);

#endif